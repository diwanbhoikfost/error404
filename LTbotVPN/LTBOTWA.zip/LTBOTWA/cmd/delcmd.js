const fs = require('fs');
const path = require('path');
module.exports = async ({ lunaticreply, args, isAdmin }) => {
if (!isAdmin) return lunaticreply('❌ Khusus admin bot!');
const filename = args[0];
if (!filename) return lunaticreply('⚠️ Format: !delcmd <namafile>.js');
const filePath = path.join(__dirname, filename);
if (!fs.existsSync(filePath)) return lunaticreply(`❌ File *${filename}* tidak ditemukan.`);
try {
fs.unlinkSync(filePath);
lunaticreply(`✅ File *${filename}* berhasil dihapus.`);
} catch (e) {
lunaticreply(`❌ Gagal menghapus file:\n${e.message}`);
}
};