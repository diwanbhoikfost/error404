const fs = require('fs');
const https = require('https');

module.exports = async ({ lunaticreply }) => {
  const tokenPath = './avars/token.json';

  if (!fs.existsSync(tokenPath)) {
    return lunaticreply('❌ File token.json tidak ditemukan di folder avars.');
  }

  const { digitalocean } = JSON.parse(fs.readFileSync(tokenPath, 'utf-8'));

  if (!digitalocean) {
    return lunaticreply('❌ Token DigitalOcean tidak ditemukan di token.json.');
  }

  const options = {
    hostname: 'api.digitalocean.com',
    path: '/v2/images?type=distribution',
    method: 'GET',
    headers: {
      Authorization: `Bearer ${digitalocean}`,
    },
  };

  const req = https.request(options, (res) => {
    let data = '';
    res.on('data', chunk => data += chunk);
    res.on('end', () => {
      try {
        const result = JSON.parse(data);
        const images = result.images || [];

        const filtered = images.filter(img =>
          ['Ubuntu', 'Debian'].includes(img.distribution)
        );

        if (!filtered.length) return lunaticreply('⚠️ Tidak ada image Ubuntu/Debian ditemukan.');

        const message = filtered
          .slice(0, 20) // maksimal 20 image
          .map(img => `• ${img.distribution} ${img.name}\n  slug: ${img.slug}`)
          .join('\n\n');

        lunaticreply(`🖥️ *Image Ubuntu & Debian (20 Pertama)*\n\n${message}`);
      } catch (err) {
        console.error('Error parsing image list:', err);
        lunaticreply('❌ Gagal memproses data image.');
      }
    });
  });

  req.on('error', (err) => {
    console.error('HTTP Request error:', err);
    lunaticreply('❌ Gagal menghubungi API DigitalOcean.');
  });

  req.end();
};
