const fs = require('fs')
const path = require('path')

module.exports = async ({ q, lunatix, msg, sender, lunaticreply, isAdmin }) => {
    if (!isAdmin) return lunaticreply("⚠️ Hanya admin bot yang bisa menambahkan owner!")

    if (!q) return lunaticreply("*EXAMPLE:* addowner 628xxx")

    const target = q.replace(/[^0-9]/g, '') // Tanpa @s.whatsapp.net
    const filePath = path.join(__dirname, '../avars/owner.json')
    let ownerList = []

    try {
        ownerList = JSON.parse(fs.readFileSync(filePath))
    } catch {
        ownerList = []
    }

    if (ownerList.includes(target)) {
        return lunaticreply("⚠️ Nomor ini sudah jadi owner!")
    }

    ownerList.push(target)
    fs.writeFileSync(filePath, JSON.stringify(ownerList, null, 2))

    lunaticreply(`✅ Berhasil menambahkan ${q} sebagai owner bot!`)
}
