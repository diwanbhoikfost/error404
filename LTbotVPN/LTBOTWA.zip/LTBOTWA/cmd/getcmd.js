const fs = require('fs');
const path = require('path');
module.exports = async ({ lunatix, msg, args, lunaticreply }) => {
const file = args[0];
if (!file || !file.endsWith('.js')) return lunaticreply('⚠️ Format: !getcmd <namafile>.js');
const filePath = path.join(__dirname, file);
if (!fs.existsSync(filePath)) return lunaticreply(`❌ File *${file}* tidak ditemukan di folder cmd/`);
try {
await lunatix.sendMessage(msg.from, {
document: fs.readFileSync(filePath),
mimetype: 'application/javascript',
fileName: file
}, { quoted: msg });
} catch (err) {
lunaticreply(`❌ Gagal mengirim file:\n${err.message}`);
}
};