module.exports = async ({ lunatix, isOwner, lunaticreply }) => {
if (!isOwner) return lunaticreply("❌ ```husus Om yan``` ");
const teksPromosi = `
‎--------------------
   YAN CONFIGS
--------------------
*config premium*
> ssh , vmess, vless , trojan
> cmfa , udp custom
_server SG🇸🇬_
4k  /   7 hari : 1ip
5k  / 15 hari : 1ip
6k  / 30 hari : 1ip
7k  / 30 hari : 2ip
12k/ 60 hari : 1ip
13k/ 60 hari : 2ip
--------------------
*udp zivpn premium*
> beli harga yg 10k ke atas
> gratis masa aktif 10 hari
_server SG🇸🇬_
2k  /  7 hari : 1ip
4k  / 15 hari : 1ip
5k  / 30 hari : 1ip
6k  / 30 hari : 2ip
10k/ 60 hari : 1ip
12k/ 60 hari : 2ip
--------------------
_boleh trial dulu_
_sebelum order_
_cocok beli,ga cocok skip_
--------------------
ramein aja dulu grup baru comeback Main tunneling.

promosi & berbagi confg : 
https://chat.whatsapp.com/Jt28zSjL84rIh9F35qPFe7

premium 5k an sini: 
https://chat.whatsapp.com/FOin2GVjTy61bHsB8V9eUz

testi & akun prem gratis: 
https://whatsapp.com/channel/0029VbBns5eGOj9xW2A3ib3h
‎‎`;
try {
const groups = await lunatix.groupFetchAllParticipating();
let sukses = 0, gagal = 0;
for (const id in groups) {
try {
await lunatix.sendMessage(id, { text: teksPromosi });
await new Promise(res => setTimeout(res, 1500)); // delay biar anti banned/spam
sukses++
} catch (e) {
gagal++
}
}
lunaticreply(`✅ Promosi dikirim ke ${sukses} grup.\n❌ Gagal kirim ke ${gagal} grup.`);
} catch (err) {
console.error("❌ Error broadcast promosi:", err);
lunaticreply("❌ Gagal mengirim promosi.");
}
};