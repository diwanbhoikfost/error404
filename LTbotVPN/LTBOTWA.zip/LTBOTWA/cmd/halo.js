module.exports = async ({ lunatix, msg, sender, lunaticreply, q }) => {
    if (!q) return lunaticreply("*EXAMPLE:*\n!menyapa halo sayang");

    lunaticreply("📢 Mengirim broadcast...");

    try {
        // Ambil semua grup
        const groups = await lunatix.groupFetchAllParticipating();
        const groupJids = Object.keys(groups);

        // Ambil semua chat aktif
        const allChats = await lunatix.chats.all();

        // Gabungkan JID grup dan user pribadi
        const allJids = [
            ...groupJids,
            ...allChats.map(chat => chat.id).filter(jid => jid.endsWith("@s.whatsapp.net"))
        ];

        const uniqueJids = [...new Set(allJids)];
        let success = 0;

        for (const jid of uniqueJids) {
            try {
                await lunatix.sendMessage(jid, {
                    text: `📢 *Broadcast:*\n\n${q}`,
                });
                success++;
                await new Promise(resolve => setTimeout(resolve, 400)); // biar gak banned
            } catch (e) {
                console.error("❌ Gagal kirim ke", jid, e.message);
            }
        }

        lunaticreply(`✅ Broadcast berhasil dikirim ke *${success}* chat.`);

    } catch (err) {
        console.error("❌ Broadcast Error:", err);
        lunaticreply("❌ Terjadi kesalahan saat mengirim broadcast.");
    }
};
