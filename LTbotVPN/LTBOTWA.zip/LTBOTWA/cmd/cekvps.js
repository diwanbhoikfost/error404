const fs = require('fs');
const path = './avars/vpsdata.json';

module.exports = async ({ isOwner, isAdmin, lunaticreply, sender }) => {
    if (!isAdmin && isOwner) return lunaticreply("❌ ```KHUSUS LUNATIC``` ");
    
  // ✅ Cek apakah data VPS tersedia
  if (!fs.existsSync(path)) return lunaticreply('❌ ```DATA VPS KOSONG```');

  const vpsData = JSON.parse(fs.readFileSync(path));
  const keys = Object.keys(vpsData);

  if (keys.length === 0) return lunaticreply('```DATA VPS KOSONG``` 🗿');

  // ✅ Format output
  let teks = '📡 *DAFTAR VPS TUNNELING:*\n\n';
  keys.forEach((nama, i) => {
  if (!isAdmin && !isOwner) return lunaticreply('❌ Fitur ini hanya untuk *Owner Bot*!');
    const { ip, pass } = vpsData[nama];
    teks += `${i + 1}. *Nama*  : ${nama}\n   *IP*    : ${ip}\n   *Pass*  : ${pass}\n\n`;
  });

  lunaticreply(teks.trim());
};