const fs = require('fs');
const axios = require('axios');

module.exports = async ({ args, lunaticreply, isAdmin }) => {
  if (!isAdmin) return lunaticreply('❌ Hanya admin yang bisa menghapus VPS.');
  if (args.length < 1) return lunaticreply('⚠️ Format salah!\nContoh: !deletevps <ip_address>');

  const ipInput = args[0].trim();

  // Ambil token dari file
  const tokenPath = './avars/token.json';
  if (!fs.existsSync(tokenPath)) {
    return lunaticreply('❌ File token tidak ditemukan di avars/token.json');
  }

  const { digitalocean: apiToken } = JSON.parse(fs.readFileSync(tokenPath));
  if (!apiToken) return lunaticreply('❌ Token DigitalOcean kosong!');

  try {
    // Ambil semua droplet
    const response = await axios.get('https://api.digitalocean.com/v2/droplets', {
      headers: {
        Authorization: `Bearer ${apiToken}`,
      },
    });

    const droplets = response.data.droplets;

    // Cari droplet dengan IP cocok
    const target = droplets.find(d => {
      const ip = d.networks.v4.find(n => n.type === 'public')?.ip_address;
      return ip === ipInput;
    });

    if (!target) {
      return lunaticreply(`❌ Tidak ada VPS dengan IP ${ipInput}`);
    }

    // Hapus droplet
    await axios.delete(`https://api.digitalocean.com/v2/droplets/${target.id}`, {
      headers: {
        Authorization: `Bearer ${apiToken}`,
      },
    });

    lunaticreply(`✅ VPS dengan IP ${ipInput} (ID: ${target.id}, Nama: ${target.name}) berhasil dihapus.`);
  } catch (err) {
    console.error('❌ Error hapus VPS:', err?.response?.data || err.message);
    lunaticreply(`❌ Gagal menghapus VPS.\n${err?.response?.data?.message || err.message}`);
  }
};
