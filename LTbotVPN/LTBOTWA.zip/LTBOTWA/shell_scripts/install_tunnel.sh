#!/bin/bash

IP=$1
USER=$2
PASS=$3
PORT=$4
INSTALLER="/root/LTBOTWA/install.sh"

# Cek file install.sh
if [ ! -f "$INSTALLER" ]; then
    echo "❌ File $INSTALLER tidak ditemukan!"
    exit 1
fi

# Pastikan sshpass ada
if ! command -v sshpass >/dev/null 2>&1; then
    apt update -y && apt install -y sshpass
fi

echo "📦 Mengirim install.sh ke VPS $IP..."
sshpass -p "$PASS" scp -P $PORT -o StrictHostKeyChecking=no "$INSTALLER" ${USER}@$IP:/root/

echo "🚀 Menjalankan install.sh di VPS $IP..."
sshpass -p "$PASS" ssh -p $PORT -o StrictHostKeyChecking=no ${USER}@$IP "chmod +x /root/install.sh && /root/install.sh"

echo "✅ Instalasi selesai di VPS $IP"
