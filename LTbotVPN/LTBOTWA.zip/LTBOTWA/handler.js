const fs   = require('fs');
const path = require('path');
require('./global'); // ⬅️ aktifkan variabel global

function getPrefix() {
  try {
    const pf = JSON.parse(fs.readFileSync('./avars/prefix.json'));
    return pf.prefix || '!';
  } catch {
    return '!';
  }
}

// 🔁 Load semua command
const commandModules = {};
const cmdPath = path.join(__dirname, 'cmd');

fs.readdirSync(cmdPath).forEach(file => {
  if (file.endsWith('.js')) {
    const cmdName = file.replace('.js', '').toLowerCase();
    commandModules[cmdName] = require(path.join(cmdPath, file));
  }
});

module.exports = async (lunatix, m) => {
  const msg = m.messages[0];
  if (!msg?.message) return;

  const body = msg.message.conversation ||
               msg.message.extendedTextMessage?.text ||
               '';

  const prefix = getPrefix();
  const from   = msg.key.remoteJid;
  const isGroup  = from.endsWith('@g.us');

  // ✅ FIX: Ambil sender dengan fallback aman
  const sender = isGroup 
    ? (msg.key.participant || msg.participant || from) 
    : from;

  const pushname = msg.pushName || 'lunatix';

  // ✅ FIX: Clean nomor pengirim
  const cleanSender = sender?.replace(/[^0-9]/g, '') || '';

  // ✅ Banned check
  const banned = JSON.parse(fs.readFileSync('./avars/banned.json'));
  if (banned.includes(cleanSender)) return;

  const isFromMe  = msg.key.fromMe;
  const ownerList = JSON.parse(fs.readFileSync('./avars/owner.json'));

  // ✅ Logika isOwner dan isAdmin diperbaiki
  const isOwner = ownerList.includes(cleanSender);
  const isAdmin = isOwner || isFromMe;

  // ⛑️ Reply helper
  const lunaticreply = text =>
    lunatix.sendMessage(from, { text }, { quoted: msg });

  // ░░░ Ambil command & args ░░░
  let command = '';
  let args = [];
  let q = '';

  if (body.startsWith(prefix)) {
    args = body.slice(prefix.length).trim().split(/\s+/);
  } else {
    args = body.trim().split(/\s+/);
  }

  command = (args.shift() || '').toLowerCase();
  q = args.join(' ');

  // 🔎 Validasi command
  const cmdModule = commandModules[command];
  if (!cmdModule) return;

  const context = {
    lunatix,
    msg,
    sender,
    pushname,
    args,
    q,
    lunaticreply,
    isGroup,
    isAdmin,
    isOwner,
    body,
    command,
  };

  try {
    if (typeof cmdModule === 'function') {
      await cmdModule(context);
    } else if (typeof cmdModule.execute === 'function') {
      await cmdModule.execute(context);
    } else {
      throw new Error('Format command tidak valid: harus function atau { execute }');
    }
  } catch (err) {
    console.error(`❌ Error di command "${command}":`, err);
    lunaticreply('❌ Terjadi error saat menjalankan perintah.');
  }
};