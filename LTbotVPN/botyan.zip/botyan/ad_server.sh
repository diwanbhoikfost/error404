#!/usr/bin/env bash
clear

DATA_DIR="/root/botyan/data"
FILE="$DATA_DIR/server.js"

mkdir -p $DATA_DIR

# Ambil info VPS
CITY=$(curl -s ipinfo.io/city)
ISP=$(curl -s ipinfo.io/org | cut -d " " -f 2-)

BIRU="\033[38;2;0;191;255m"
HIJAU="\033[38;2;173;255;47m"
PUTIH="\033[38;2;255;255;255m"
CYANS="\033[38;2;35;235;195m"
GOLD="\033[38;2;255;215;0m"
RESET="\033[0m"

# Warna
red='\033[38;5;197m'
yellow='\033[38;5;227m'
cyan='\033[96;1m'
white='\033[97;1m'
reset='\033[0m'


function Ad_server() {
clear 
printf "${BIRU}────────────────────────────────────────${RESET}\n"
echo -e "\033[0;35m       ADDED VPS SERVER RESULT TO TELEGRAM BOT       \033[0m"
printf "${BIRU}────────────────────────────────────────${RESET}\n"
echo -e "${CYANS}● Tambahkan Server Vps Tujuan ( ip , pw , domain ) ${RESET}"
echo -e "${CYANS}● Untuk Mengaktifkan Fitur Bot MultiServer ${RESET}"
echo -e "${CYANS}● Kendalikan semua server dalam 1 BOT ${RESET}"
printf "${BIRU}────────────────────────────────────────${RESET}\n"
echo -e "${GOLD}- Untuk memasukan nama Server :  ${RESET}"
echo -e "${GOLD}- Contoh : Indonesia Biznet , Indonesia Rumahweb (bebas)${RESET}"
printf "${BIRU}────────────────────────────────────────${RESET}\n"
echo -e ""
clear

DATA_DIR="/root/botyan/data"
FILE="$DATA_DIR/server.js"

mkdir -p $DATA_DIR

# Ambil info VPS
CITY=$(curl -s ipinfo.io/city)
ISP=$(curl -s ipinfo.io/org | cut -d " " -f 2-)

# Input user
read -p "Masukan IP VPS         : " ipvps
read -p "Masukan Password VPS : " pw
read -p "Masukan Domain        : " host
read -0 "Masukan server (ID/SG) : " lok

# Jika file belum ada, buat template awal
if [ ! -f "$FILE" ]; then
cat > $FILE <<'EOF'
const servers = [
];

module.exports = servers;
EOF
fi

# Ambil ID terakhir
LAST_ID=$(grep "id:" $FILE | tail -n1 | grep -oE '[0-9]+' || echo 0)
NEW_ID=$((LAST_ID + 1))

# Buat object server baru
NEW_SERVER=$(cat <<EOF
  {
    id: $NEW_ID,
    name: "🌏 $lok",
    ip: "$ipvps",
    pass: "$pw",
    domain: "$host",
    provider: "$ISP"
  }
EOF
)

# Sisipkan sebelum penutup array ];
sed -i "/^];/i $NEW_SERVER," $FILE

echo ""
echo "✅ Server berhasil ditambahkan!"
echo "📍 City     : $CITY"
echo "🏢 Provider : $ISP"
echo "🆔 ID       : $NEW_ID"
pm2 restart botyan

}


# Mengecek status PM2 process dengan nama "LUNATIXBOT"
if pm2 list | grep -q 'botyan' && pm2 status botyan | grep -q 'online'; then
    status_bot="\033[32;1mONLINE\033[0m"  # Hijau jika aktif
else
    status_bot="\033[31;1mOFFLINE\033[0m"  # Merah jika mati
fi

# Mengecek status PM2 process dengan nama "LTBOTWA"
if pm2 list | grep -q 'LTBOTWA' && pm2 status LTBOTWA | grep -q 'online'; then
    sts_bot="\033[32;1mONLINE\033[0m"  # Hijau jika aktif
else
    sts_bot="\033[31;1mOFFLINE\033[0m"  # Merah jika mati
fi

# Tampilan menu
printf "${BIRU}────────────────────────────────────────${RESET}\n"
echo -e "\033[0;35m         FEATURE BOT TELEGRAM      \033[0m"
echo -e "\033[97;1m         STATUS BOT : ${status_bot}   \033[0m"
printf "${BIRU}────────────────────────────────────────${RESET}\n"
printf "${HIJAU} 1) ${GOLD} Tambahkan server VPS      ${RESET}\n"
printf "${HIJAU} 2) ${GOLD} Restarting bot                ${RESET}\n"
printf "${HIJAU} 3) ${GOLD} Ganti Harga Protocol         ${RESET}\n"
printf "${BIRU}────────────────────────────────────────${RESET}\n"
echo -e "\033[0;35m         FEATURE BOT WHATSAPP      \033[0m"
echo -e "\033[97;1m         STATUS BOT : ${sts_bot}       \033[0m"
printf "${BIRU}────────────────────────────────────────${RESET}\n"
printf "${HIJAU} 4) ${GOLD} Tambahkan Server VPS    ${RESET}\n"
printf "${HIJAU} 5) ${GOLD} Restarting Bot              ${RESET}\n"
printf "${HIJAU} 6) ${GOLD} Ganti Harga Protocol       ${RESET}\n"
printf "${HIJAU} x) ${GOLD} EXIT                        ${RESET}\n"
printf "${BIRU}────────────────────────────────────────${RESET}\n"
echo ""

# Input pilihan
read -p " Just Input 1-5 or 'x' to quit: " SELECT_INPUT
case $SELECT_INPUT in
  1) clear ; Ad_server ;;
  2) clear ; pm2 restart botyan ;;
  3) clear ; ganti_harga_tl ;;
  4) clear ; Ad_server_wa ;;
  5) clear ; pm2 restart LTBOTWA ;;
  6) clear ; ganti_harga_wa ;; 
  x|X) exit ;;
  *) echo -e "\033[91m❌ Input tidak dikenali!\033[0m" ;;
esac

exec bash