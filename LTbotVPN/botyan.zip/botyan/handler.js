// handler.js - UPDATED VERSION WITH ROLE DETECTION
const fs = require('fs');
const path = require('path');
const os = require('os');
const fsp = fs.promises;

// Load DB & Config
const db = require('./data/db');
const LIST_SERVER = require('./data/server');
const axios = require('axios');

// Load paymentChecker
const { addPendingOrder, checkPaymentStatus } = require('./services/paymentChecker');

// Load Core Modules
const create = require('./cmd/create');
const renew = require('./cmd/renew');
const triall = require('./cmd/triall');

/* ─────────────── STATE MAPS ─────────────── */
const userMenus = new Map();   // simpan id pesan menu terakhir
const userStates = new Map();  // chatId → { state: string, data?: any }
const pendingInputs = new Set(); // Menandai user yang sedang input

/* ─────────────── HELPERS ─────────────── */
async function sendMenu(bot, chatId, map, text, opts) {
  if (map.has(chatId)) {
    const old = map.get(chatId);
    bot.deleteMessage(chatId, old).catch(() => {});
  }
  const sent = await bot.sendMessage(chatId, text, opts);
  map.set(chatId, sent.message_id);
  return sent;
}

/* ─────────────── STATISTIK ─────────────── */
function getAccountStatsGlobal() {
  return new Promise((resolve) => {
    db.get(`
      SELECT
        COUNT(CASE WHEN date(created_at) = date('now', 'localtime') THEN 1 END) AS today,
        COUNT(CASE WHEN strftime('%Y-%W', created_at) = strftime('%Y-%W', 'now', 'localtime') THEN 1 END) AS week,
        COUNT(CASE WHEN strftime('%Y-%m', created_at) = strftime('%Y-%m', 'now', 'localtime') THEN 1 END) AS month
      FROM transactions
      WHERE status='completed'
    `, [], (err, row) => {
      if (err || !row) return resolve({ today: 0, week: 0, month: 0 });
      resolve(row);
    });
  });
}

function getAccountStatsUser(chatId) {
  return new Promise((resolve) => {
    db.get(`
      SELECT
        COUNT(CASE WHEN date(created_at) = date('now', 'localtime') THEN 1 END) AS today,
        COUNT(CASE WHEN strftime('%Y-%W', created_at) = strftime('%Y-%W', 'now', 'localtime') THEN 1 END) AS week,
        COUNT(CASE WHEN strftime('%Y-%m', created_at) = strftime('%Y-%m', 'now', 'localtime') THEN 1 END) AS month
      FROM transactions
      WHERE status='completed' AND chat_id = ?
    `, [chatId], (err, row) => {
      if (err || !row) return resolve({ today: 0, week: 0, month: 0 });
      resolve(row);
    });
  });
}

/* ─────────────── HANDLER UTAMA ─────────────── */
function handler(bot) {
  bot.on('message', async (msg) => {
    const chatId = msg.chat.id;
    const text = msg.text?.trim();
    if (!text) return;

    const stateObj = userStates.get(chatId);
    const state = stateObj?.state;

    if (state === 'deposit_custom') {
      if (!/^\d+$/.test(text)) {
        return bot.sendMessage(chatId, '❌ Masukkan angka saja ya bro. Contoh: `15000`');
      }
      const amount = parseInt(text);
      if (amount < 5000) return bot.sendMessage(chatId, '❌ Minimal Top Up Rp 5.000');
      
      userStates.delete(chatId);
      return generateQRIS(bot, chatId, amount);
    }

    if (text === '/start') {
      db.get("SELECT role FROM users WHERE chat_id = ?", [chatId], (err, row) => {
        if (!row) {
          // USER BARU: Default role 'buyer'
          db.run("INSERT INTO users (chat_id, saldo, role, created_at) VALUES (?, 0, 'buyer', datetime('now','localtime'))", [chatId]);
        }
        bot.sendMessage(chatId, '✅ *Welcome to DIWANTUNNELING!*\nKetik /menu untuk berbelanja.', { parse_mode: 'Markdown' });
      });
    } else if (text === '/menu') {
      sendMainMenu(bot, chatId);
    } else if (text === '/cancel') {
      userStates.delete(chatId);
      pendingInputs.delete(chatId);
      bot.sendMessage(chatId, '❌ Proses dibatalkan.');
    }
  });

  bot.on('callback_query', async (query) => {
    const chatId = query.message.chat.id;
    const data = query.data;
    
    bot.deleteMessage(chatId, query.message.message_id).catch(() => {});

    if (data === 'menu_back') {
      userStates.delete(chatId);
      return sendMainMenu(bot, chatId);
    }

    if (data === 'menu_deposit') {
      const depositFile = path.join(__dirname, 'cmd', 'menu_deposit.js');
      if (fs.existsSync(depositFile)) return require(depositFile)(bot, chatId);
    }

    if (data.startsWith('deposit_')) {
      const amountStr = data.split('_')[1];
      if (amountStr === 'custom') {
        userStates.set(chatId, { state: 'deposit_custom' });
        return bot.sendMessage(chatId, '🏦 **TOPUP CUSTOM**\nMasukkan nominal (contoh: 20000):');
      }
      const amount = parseInt(amountStr);
      if (!isNaN(amount)) return generateQRIS(bot, chatId, amount);
    }

    if (data.startsWith('refresh_')) {
      const orderId = data.split('_')[1];
      return checkPaymentStatus(bot, chatId, orderId);
    }

    if (data === 'create_menu') return sendServerSelection(bot, chatId, 'create');
    if (data === 'triall_menu') return sendServerSelection(bot, chatId, 'triall');
    if (data === 'renew_menu') return sendServerSelection(bot, chatId, 'renew');

    if (data.startsWith('select_')) {
      const [_, type, idx] = data.split('_');
      userStates.set(chatId, { state: `${type}_flow`, serverIp: LIST_SERVER[parseInt(idx)].ip });
      if (type === 'create') return sendCreateMenu(bot, chatId);
      if (type === 'triall') return sendTriallMenu(bot, chatId);
      if (type === 'renew') return sendRenewMenu(bot, chatId);
    }

    const actions = {
      'ssh_create': create.createSSH, 'ziv_create': create.createZivpn,
      'vme_create': create.createVMess, 'vle_create': create.createVLess, 'tro_create': create.createTrojan,
      'ssh_triall': triall.trialSSH, 'ziv_triall': triall.trialZivpn,
      'vme_triall': triall.trialVMess, 'vle_triall': triall.trialVLess, 'tro_triall': triall.trialTrojan,
      'ssh_renew': renew.renewSSH, 'ziv_renew': renew.renewZivpn,
      'vme_renew': renew.renewVMess, 'vle_renew': renew.renewVLess, 'tro_renew': renew.renewTrojan
    };

    if (actions[data]) {
      if (data.includes('triall')) {
        actions[data](bot, chatId, userStates, pendingInputs);
      } else {
        actions[data](bot, chatId, userStates);
      }
      return bot.answerCallbackQuery(query.id);
    }
  });
}

/* ─────────────── MENU GENERATOR (DETEKSI ROLE) ─────────────── */
async function sendMainMenu(bot, chatId) {
  db.get("SELECT saldo, role FROM users WHERE chat_id = ?", [chatId], async (err, row) => {
    const saldo = Number(row?.saldo) || 0;
    const role = row?.role || 'buyer'; // Deteksi role, default buyer
    
    const [globalStats, userStats] = await Promise.all([
      getAccountStatsGlobal(), 
      getAccountStatsUser(chatId)
    ]);

    const text = `
─────────────────
 <b>DIWAN AUTO ORDERS</b>
─────────────────
 <b>Role :</b> <code>${role.toUpperCase()}</code>
 <b>ID:</b> <code>${chatId}</code>
 <b>Balance:</b> <code>Rp ${saldo.toLocaleString('id-ID')}</code>
─────────────────
<b>- Udp Zivpn prices : 250p</b>
<b>- ssh vmess prices : 400p</b>
<blockquote>
<b>GLOBAL STATISTIC:</b>
 ● Hari ini : ${globalStats.today}
 ● Minggu ini : ${globalStats.week}
 ● Bulan ini : ${globalStats.month}
<b>YOUR STATISTIC:</b>
 ● Hari ini : ${userStats.today}
 ● Minggu ini : ${userStats.week}
 ● Bulan ini : ${userStats.month}
 </blockquote>
 top up di atas 25k = RESELLER
 top up di bwh 25k = BUYYER
─────────────────
<i>contack: 081312868913</i>
<i>tlegram: @diwanvpn</i>
<i>Creator: DiwanTunneling</i>
`;

    const keyboard = [
      [{ text: 'Create Account', callback_data: 'create_menu' }, { text: 'Trial Account', callback_data: 'triall_menu' }],
      [{ text: 'Renew Account', callback_data: 'renew_menu' }, { text: '💰 TOP UP 💰', callback_data: 'menu_deposit' }]
    ];

    sendMenu(bot, chatId, userMenus, text, { 
      parse_mode: 'HTML', 
      reply_markup: { inline_keyboard: keyboard } 
    });
  });
}

/* ─────────────── PILIH SERVER VPS ─────────────── */
async function sendServerSelection(bot, chatId, actionType) {
  const keyboard = LIST_SERVER.map((srv, idx) => [{ text: ` ${srv.name} 🌍`, callback_data: `select_${actionType}_${idx}` }]);
  keyboard.push([{ text: '🔙 Back', callback_data: 'menu_back' }]);
  bot.sendMessage(chatId, '<blockquote>SELECT SERVER</blockquote>', { parse_mode: 'HTML', reply_markup: { inline_keyboard: keyboard } });
}

/* ─────────────── PILIH PROTOCOL CREATE ─────────────── */
function sendCreateMenu(bot, chatId) {
  const keyboard = [
    [{ text: 'SSHWS', callback_data: 'ssh_create' }, { text: 'ZIVPN', callback_data: 'ziv_create' }],
    [{ text: 'VMESS', callback_data: 'vme_create' }, { text: 'VLESS', callback_data: 'vle_create' }],
    [{ text: 'TROJAN', callback_data: 'tro_create' }, { text: '🔙 Back', callback_data: 'menu_back' }]
  ];
  bot.sendMessage(chatId, '🛠CREATE PREMIUM🛠', { reply_markup: { inline_keyboard: keyboard } });
}

/* ─────────────── PILIH PROTOCOL TRIAL ─────────────── */
function sendTriallMenu(bot, chatId) {
  const keyboard = [
    [{ text: 'SSHWS', callback_data: 'ssh_triall' }, { text: 'ZIVPN', callback_data: 'ziv_triall' }],
    [{ text: 'VMESS', callback_data: 'vme_triall' }, { text: 'VLESS', callback_data: 'vle_triall' }],
    [{ text: 'TROJAN', callback_data: 'tro_triall' }, { text: '🔙 Back', callback_data: 'menu_back' }]
  ];
  bot.sendMessage(chatId, '🧪TRIAL ACCOUNT🧪', { reply_markup: { inline_keyboard: keyboard } });
}

/* ─────────────── PILIH PROTOCOL RENEW ─────────────── */
function sendRenewMenu(bot, chatId) {
  const keyboard = [
    [{ text: 'SSHWS', callback_data: 'ssh_renew' }, { text: 'ZIVPN', callback_data: 'ziv_renew' }],
    [{ text: 'VMESS', callback_data: 'vme_renew' }, { text: 'VLESS', callback_data: 'vle_renew' }],
    [{ text: 'TROJAN', callback_data: 'tro_renew' }, { text: '🔙 Back', callback_data: 'menu_back' }]
  ];
  bot.sendMessage(chatId, '🔄RENEW ACCOUNT🔄', { reply_markup: { inline_keyboard: keyboard } });
}

async function generateQRIS(bot, chatId, amount) {
  const orderId = `${chatId}_${Date.now()}`;
  const avarsPath = path.join(__dirname, 'data', '.avars.json');
  const avars = fs.existsSync(avarsPath) ? JSON.parse(fs.readFileSync(avarsPath)) : {};

  if (!avars.pakasir_slug || !avars.pakasir_api_key) {
    return bot.sendMessage(chatId, '❌ Konfigurasi Pakasir belum lengkap.');
  }

  bot.sendMessage(chatId, `⌛ Generate QRIS Rp ${amount.toLocaleString('id-ID')}...`);

  try {
    const QRCode = require('qrcode');
    const createRes = await axios.post('https://app.pakasir.com/api/transactioncreate/qris', {
      project: avars.pakasir_slug,
      order_id: orderId,
      amount: amount,
      api_key: avars.pakasir_api_key,
    });

    const txData = createRes.data;
    if (!txData.payment?.payment_number) throw new Error('Gagal dapat QR string');

    const qrBuffer = await QRCode.toBuffer(txData.payment.payment_number, { width: 300 });

    db.run("INSERT INTO transactions (chat_id, order_id, amount, status, created_at) VALUES (?, ?, ?, 'pending', datetime('now','localtime'))", [chatId, orderId, amount]);

    await bot.sendPhoto(chatId, qrBuffer, {
      caption: `💳PEMBAYARAN QRIS\n\nNominal: Rp ${amount.toLocaleString('id-ID')}\nOrder ID: \`${orderId}\`\n\nSaldo otomatis masuk setelah lunas.`,
      parse_mode: 'Markdown',
      reply_markup: {
        inline_keyboard: [
          [{ text: '🔄 Refresh', callback_data: `refresh_${orderId}` }],
          [{ text: '🔙 Kembali', callback_data: 'menu_back' }]
        ]
      }
    });

    addPendingOrder(orderId, { chatId, amount, productName: 'Topup Saldo' });
  } catch (err) {
    bot.sendMessage(chatId, '❌ Gagal membuat QRIS.');
  }
}

module.exports = handler;