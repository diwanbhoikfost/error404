#!/bin/bash

##### BASE : LUNATIC TUNNELING x GPT #####

# Lunatic Tunneling | Dian Permana
# Saguling | Jawa Barat | Bandung Barat | Indonesia
# Contact | wa.me/6283197765857

set -e
clear

GREEN="\e[92;1m"
RED="\e[31m"
RESET="\e[0m"

echo -e "${GREEN}=== SETUP BOT TELEGRAM RESSELLER PAKASIR ===${RESET}"

# Install kebutuhan dasar
apt update -y &> /dev/null
apt install -y unzip wget curl &> /dev/null

# Cek & install Node.js + npm (versi 20.x recommended untuk stability)
if command -v node >/dev/null && command -v npm >/dev/null; then
    echo -e "${GREEN}✔ Node.js dan npm sudah terpasang${RESET}"
else
    echo -e "${RED}Menginstall Node.js dari Nodesource...${RESET}"
    curl -fsSL https://deb.nodesource.com/setup_20.x | bash - &> /dev/null
    apt install -y nodejs &> /dev/null
    echo -e "${GREEN}✔ Node.js & npm terinstall${RESET}"
fi

# Install PM2 global
if ! command -v pm2 >/dev/null; then
    echo -e "${RED}Menginstall PM2...${RESET}"
    npm install -g pm2 &> /dev/null
else
    echo -e "${GREEN}✔ PM2 sudah ada${RESET}"
fi

# Download dan extract bot (asumsi link zip bot kamu benar)
wget -O botyan.zip https://raw.githubusercontent.com/diwanbhoikfost/error404/main/LTbotVPN/botyan  # ganti link kalau perlu
[[ ! -f "botyan.zip" ]] && { echo -e "${RED}Gagal download file bot${RESET}"; exit 1; }

rm -rf /tmp/botyan_EXTRACT
mkdir -p /tmp/botyan_EXTRACT
unzip -o botyan.zip -d /tmp/botyan_EXTRACT &> /dev/null

BOT_FOLDER=$(find /tmp/botyan_EXTRACT -maxdepth 1 -type d ! -name "*EXTRACT" | head -n 1)
[[ -z "$BOT_FOLDER" ]] && { echo -e "${RED}Folder bot tidak ditemukan!${RESET}"; exit 1; }

rm -rf /usr/bin/botyan
mv "$BOT_FOLDER" /usr/bin/botyan
chmod +x /usr/bin/botyan/shell_script/* 2>/dev/null || true

# Warna tambahan
BIRU="\033[38;2;0;191;255m"
HIJAU="\033[38;2;173;255;47m"
PUTIH="\033[38;2;255;255;255m"
CYANS="\033[38;2;35;235;195m"
GOLD="\033[38;2;255;215;0m"
RESET="\033[0m"

# Input data user
clear
printf "${BIRU}────────────────────────────────────────${RESET}\n"
echo -e "     ${CYANS}SETUP DATA BOT RESSELLER${RESET}"
printf "${BIRU}────────────────────────────────────────${RESET}\n"
echo -e "${HIJAU}Masukkan data berikut dengan benar:${RESET}"
echo ""

printf "${BIRU} Wajib isi Token Bot${RESET}\n"
read -p "BOT TOKEN (dari @BotFather) : " BOT_TOKEN
[[ -z "$BOT_TOKEN" ]] && { echo -e "Token tidak boleh kosong!"; exit 1; }

echo
printf "${GOLD} Wajib isi id telegram${RESET}\n"
read -p "OWNER ID (ID Telegram kamu) : " OWNER_ID
[[ -z "$OWNER_ID" ]] && { echo -e "Owner ID tidak boleh kosong!${RESET}"; exit 1; }

echo
printf "${BIRU}────────────────────────────────────────${RESET}\n"
echo -e "     ${CYANS}SETUP DATA QRIS PAYMENT GATEWAY (pakasir)${RESET}"
printf "${BIRU}────────────────────────────────────────${RESET}\n"
echo
printf "${GOLD} Slug Tidak Boleh Kosong${RESET}\n"
read -p "PAKASIR SLUG : " PAKASIR_SLUG
[[ -z "$PAKASIR_SLUG" ]] && { echo -e "Slug Pakasir tidak boleh kosong!${RESET}"; exit 1; }

echo
printf "${GOLD} APIKEY Tidak Boleh Kosong${RESET}\n"
read -p "PAKASIR API KEY : " PAKASIR_API_KEY
[[ -z "$PAKASIR_API_KEY" ]] && { echo -e "API Key Pakasir tidak boleh kosong!${RESET}"; exit 1; }


read -p "NAMA TOKO / BOT: " BOT_NAME
[[ -z "$BOT_NAME" ]] && BOT_NAME="YAN GROK VPN"  # default kalau kosong

# Buat .avars.json
mkdir -p /usr/bin/botyan/data
cat > /usr/bin/botyan/data/.avars.json << EOF
{
  "token": "$BOT_TOKEN",
  "owner_id": "$OWNER_ID",
  "pakasir_slug": "$PAKASIR_SLUG",
  "pakasir_api_key": "$PAKASIR_API_KEY",
  "bot_name": "$BOT_NAME"
}
EOF

echo -e "${GREEN}✔ Data berhasil disimpan di /usr/bin/botyan/data/.avars.json${RESET}"

# Install dependency bot
echo -e "${GREEN}Menginstall modul node-telegram-bot-api...${RESET}"
cd /usr/bin/botyan
npm install node-telegram-bot-api &> /dev/null


# Install tambahan untuk Pakasir & cron (kalau belum)
echo -e "${GREEN}Menginstall modul node-cron...${RESET}"
npm install axios node-cron sqlite3 &> /dev/null


# install qrqode canvas
echo -e "${GREEN}Menginstall module qrqode canvas...${RESET}"
npm install qrcode canvas &> /dev/null

# Jalankan bot via PM2
cd /usr/bin/botyan
pm2 start index.js --name botyan
pm2 save &> /dev/null

# Cleanup
cd ~
rm -f botyan.zip
rm -rf /tmp/botyan_EXTRACT

clear
printf "${BIRU}────────────────────────────────────────${RESET}\n"
echo -e "     ${CYANS}SETUP BOT RESSELLER SELESAI!${RESET}"
printf "${BIRU}────────────────────────────────────────${RESET}\n"
echo -e "${HIJAU}Nama Bot     : ${GOLD}$BOT_NAME${RESET}"
echo -e "${HIJAU}Token        : ${GOLD}${BOT_TOKEN:0:10}... (hidden)${RESET}"
echo -e "${HIJAU}Owner ID     : ${GOLD}$OWNER_ID${RESET}"
echo -e "${HIJAU}Pakasir Slug : ${GOLD}$PAKASIR_SLUG${RESET}"
echo -e "${HIJAU}Pakasir Key  : ${GOLD}${PAKASIR_API_KEY:0:10}... (hidden)${RESET}"
echo ""
echo -e "${GREEN}Bot sudah jalan! Buka Telegram → ketik /menu${RESET}"
echo -e "${GREEN}Cek status: pm2 logs botyan${RESET}"
printf "${BIRU}────────────────────────────────────────${RESET}\n"