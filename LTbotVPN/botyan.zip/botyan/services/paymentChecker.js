// services/paymentChecker.js
const axios = require('axios');
const fs = require('fs');
const path = require('path');

// Load database
const db = require('../data/db');  // pastikan path ini benar ke db.js lu

// Load config dari data/.avars.json
const configPath = path.join(__dirname, '../data/.avars.json');
let config;
try {
  config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
} catch (err) {
  console.error('Gagal load .avars.json:', err.message);
  process.exit(1);
}

const PAKASIR_BASE_URL = 'https://app.pakasir.com/api';
const PROJECT = config.pakasir_slug;
const API_KEY = config.pakasir_api_key;
const BOT_NAME = config.bot_name || 'LUNATIXBOT';
const OWNER_ID = config.owner_id;  // untuk notif error (opsional)

if (!PROJECT || !API_KEY) {
  throw new Error('pakasir_slug atau pakasir_api_key tidak ditemukan di .avars.json');
}

console.log(`[${BOT_NAME}] Pakasir config loaded: Project = ${PROJECT}`);

// Simpan pending orders di memory (orderId → info)
const pendingOrders = new Map(); // key: orderId, value: {chatId, amount, productName?, ...}

const CHECK_INTERVAL = 10000; // 10 detik

/**
 * Tambah order ke daftar pending (dipanggil setelah generate QR)
 */
function addPendingOrder(orderId, info) {
  pendingOrders.set(orderId, {
    ...info,
    createdAt: Date.now(),
    status: 'pending'
  });
  console.log(`[${BOT_NAME}] Added pending: ${orderId} (total: ${pendingOrders.size})`);
}

/**
 * Hapus order dari pending
 */
function removePendingOrder(orderId) {
  if (pendingOrders.delete(orderId)) {
    console.log(`[${BOT_NAME}] Removed pending: ${orderId} (total: ${pendingOrders.size})`);
  }
}

/**
 * Buat transaksi QRIS baru di Pakasir
 */
async function createQrisPayment(orderId, amount) {
  try {
    const response = await axios.post(
      `${PAKASIR_BASE_URL}/transactioncreate/qris`,
      {
        project: PROJECT,
        order_id: orderId,
        amount: amount,
        api_key: API_KEY
      },
      { headers: { 'Content-Type': 'application/json' } }
    );

    const data = response.data;

    if (!data || !data.payment) {
      throw new Error('Response Pakasir tidak valid');
    }

    return {
      orderId,
      qrString: data.payment.payment_number,
      totalPayment: data.payment.total_payment,
      fee: data.payment.fee,
      expiredAt: data.payment.expired_at || null
    };
  } catch (err) {
    console.error(`[${BOT_NAME}] Gagal create QRIS:`, err.message);
    if (err.response) console.error(err.response.data);
    throw err;
  }
}

/**
 * Cek status satu transaksi
 */
async function checkPaymentStatus(orderId, amount) {
  try {
    const url = `${PAKASIR_BASE_URL}/transactiondetail?project=${PROJECT}&amount=${amount}&order_id=${orderId}&api_key=${API_KEY}`;
    const response = await axios.get(url);
    const data = response.data;

    if (data && data.transaction) {
      return data.transaction;
    }
    return { status: 'not_found' };
  } catch (err) {
    console.error(`[${BOT_NAME}] Error check status ${orderId}:`, err.message);
    return { status: 'error', error: err.message };
  }
}

/**
 * Background checker: cek semua pending orders
 * @param {TelegramBot} bot 
 */
function startPaymentChecker(bot) {
  console.log(`[${BOT_NAME}] Payment checker STARTED (interval ${CHECK_INTERVAL/1000}s)`);

  setInterval(async () => {
    if (pendingOrders.size === 0) return;

    console.log(`[${BOT_NAME}] Checking ${pendingOrders.size} pending orders...`);

    for (const [orderId, info] of pendingOrders.entries()) {
      const tx = await checkPaymentStatus(orderId, info.amount);

      if (tx.status === 'completed') {
        try {
          // 1. Kirim pesan sukses ke user
          await bot.sendMessage(
            info.chatId,
            `✅ PEMBAYARAN BERHASIL!\n\n` +
            `Order ID: ${orderId}\n` +
            `Nominal: Rp ${info.amount.toLocaleString('id-ID')}\n` +
            `Produk: ${info.productName || 'Topup Saldo'}\n\n` +
            `Saldo sudah ditambahkan otomatis. Cek /menu atau /saldo ya! 🔥`
          );

 // 2. Update saldo user di tabel users & UPDATE ROLE OTOMATIS
          db.run(
            "UPDATE users SET saldo = saldo + ? WHERE chat_id = ?",
            [info.amount, info.chatId],
            function(err) {
              if (err) {
                console.error(`DB update saldo error untuk ${orderId}:`, err.message);
                // ... notif owner ...
              } else {
                console.log(`[${BOT_NAME}] Saldo user ${info.chatId} +Rp ${info.amount}`);

                // --- LOGIKA UPDATE ROLE ---
                // Jika top up >= 25.000, role jadi reseller. Jika tidak, tetap/jadi buyer.
                const newRole = info.amount >= 25000 ? 'reseller' : 'buyer';
                
                db.run("UPDATE users SET role = ? WHERE chat_id = ?", [newRole, info.chatId], (roleErr) => {
                  if (!roleErr) {
                    console.log(`[${BOT_NAME}] User ${info.chatId} role updated to: ${newRole}`);
                    
                    // Kirim notifikasi perubahan role ke user
                    bot.sendMessage(
                      info.chatId, 
                      `✨ Selamat! Kamu sekarang adalah *${newRole.toUpperCase()}* karena top up sebesar Rp ${info.amount.toLocaleString('id-ID')}`,
                      { parse_mode: 'Markdown' }
                    ).catch(() => {});
                  }
                });
              }
            }
          );

          // 3. Update status transaksi di DB
          db.run(
            "UPDATE transactions SET status = 'completed', completed_at = datetime('now') WHERE order_id = ?",
            [orderId],
            (err) => {
              if (err) console.error(`Gagal update status transaksi ${orderId}:`, err);
            }
          );

          removePendingOrder(orderId);

        } catch (err) {
          console.error(`Gagal proses completed ${orderId}:`, err.message);
        }
      } 
      else if (tx.status === 'canceled' || tx.status === 'expired') {
        try {
          await bot.sendMessage(
            info.chatId,
            `❌ Order ${orderId} dibatalkan/kadaluarsa.\nSilakan buat order baru.`
          );

          // Optional: update status di DB jadi canceled/expired
          db.run(
            "UPDATE transactions SET status = ? WHERE order_id = ?",
            [tx.status, orderId]
          );

          removePendingOrder(orderId);
        } catch (err) {
          console.error(`Gagal kirim pesan cancel ${orderId}:`, err);
        }
      }
      // else pending → lanjut tunggu
    }
  }, CHECK_INTERVAL);
}

module.exports = {
  createQrisPayment,
  checkPaymentStatus,
  addPendingOrder,
  removePendingOrder,
  startPaymentChecker
};