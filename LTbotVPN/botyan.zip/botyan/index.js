// index.js
const fs = require('fs');
const path = require('path');
const TelegramBot = require('node-telegram-bot-api');

// ===============================
// LOAD CONFIG
// ===============================
const avarsPath = path.join(__dirname, 'data', '.avars.json');
let avars;

try {
  avars = fs.existsSync(avarsPath)
    ? JSON.parse(fs.readFileSync(avarsPath, 'utf8'))
    : {};
} catch (err) {
  console.error('❌ Gagal baca .avars.json:', err.message);
  process.exit(1);
}

if (!avars.token) {
  console.error('❌ Token bot tidak ditemukan di .avars.json!');
  process.exit(1);
}

// ===============================
// INIT BOT
// ===============================
const bot = new TelegramBot(avars.token, { polling: true });
console.log(`\n[${avars.bot_name || 'BOT'}] Status: Online 🚀`);

// ===============================
// LOAD HANDLER
// ===============================
// Import handler utama
const runHandler = require('./handler');

try {
  // Cukup panggil bot saja, karena userStates sudah dikelola di dalam handler.js
  runHandler(bot);
  console.log('✅ Handler loaded successfully');
} catch (err) {
  console.error('❌ Gagal load handler:', err.message);
}

// ===============================
// PAYMENT CHECKER
// ===============================
const { startPaymentChecker } = require('./services/paymentChecker');

try {
  startPaymentChecker(bot);
  console.log('✅ Payment checker (Pakasir) is active');
} catch (err) {
  console.error('❌ Gagal start payment checker:', err.message);
}

// ===============================
// ERROR HANDLING (Biar bot gak mati kalau crash)
// ===============================
bot.on('polling_error', (error) => {
  console.error(`⚠️ Polling error: ${error.code} - ${error.message}`);
});

process.on('uncaughtException', (err) => {
  console.error('🔥 Ada error tak terduga:', err);
});

console.log('Bot running, siap melayani order! ☠\n');