// triall.js - UPDATED WITH ANTI-SPAM & ROLE LOGIC
const { Client } = require('ssh2');
const db = require('../data/db');
const servers = require('../data/server');
const fs = require('fs');
const path = require('path');

/* ─────────────── HELPERS ─────────────── */
function randomString(length = 6) {
  const chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
  let result = '';
  for (let i = 0; i < length; i++) {
    result += chars[Math.floor(Math.random() * chars.length)];
  }
  return result;
}

function randomUsername(prefix) {
  const num = Math.floor(1000 + Math.random() * 9000);
  return `${prefix}${num}`;
}

function silentDelete(bot, chatId, messageId) {
  if (!messageId) return;
  bot.deleteMessage(chatId, messageId).catch(() => {});
}

function finishProcess(bot, chatId, pendingInputs, text) {
  pendingInputs.delete(chatId);
  bot.sendMessage(chatId, text, { parse_mode: 'Markdown' }).catch(() => {});
}

// FUNGSI CEK LIMIT TRIAL HARIAN (ANTI-SPAM)
function checkTrialLimit(chatId, callback) {
  db.get(`
    SELECT COUNT(*) as total FROM transactions 
    WHERE chat_id = ? AND product_type LIKE 'TRIAL%' 
    AND date(created_at) = date('now', 'localtime')`, 
    [chatId], (err, row) => {
      if (err) return callback(false);
      callback(row.total < 1); // True jika belum pernah trial hari ini
  });
}

/* ─────────────── REMOTE EXECUTION ENGINE ─────────────── */
function executeScriptRemote(serverIp, scriptFileName, args, callback) {
  const serverConfig = servers.find(s => s.ip === serverIp);
  if (!serverConfig) return callback(new Error('Server tidak terdaftar.'));

  const scriptPath = path.join(__dirname, '..', 'shell_script', scriptFileName);
  if (!fs.existsSync(scriptPath)) return callback(new Error(`File ${scriptFileName} tidak ada`));
  
  const scriptContent = fs.readFileSync(scriptPath, 'utf8');
  const conn = new Client();

  conn.on('ready', () => {
    const command = `bash -s -- ${args.join(' ')}`;
    conn.exec(command, (err, stream) => {
      if (err) return callback(err);
      let output = '';
      stream.on('data', (data) => { output += data; });
      stream.on('stderr', (data) => { output += data; });
      stream.on('close', () => {
        conn.end();
        callback(null, output.trim());
      });
      stream.end(scriptContent);
    });
  }).on('error', (err) => callback(err))
    .connect({ host: serverIp, port: 22, username: 'root', password: serverConfig.pass });
}

/* ─────────────── CORE TRIAL LOGIC ─────────────── */
async function runTrial(bot, chatId, userStates, pendingInputs, config) {
  const stateData = userStates.get(chatId);
  if (!stateData?.serverIp) return bot.sendMessage(chatId, '❌ Server belum dipilih.');

  if (pendingInputs.has(chatId)) return bot.sendMessage(chatId, '⚠️ Masih ada proses lain.');

  // AMBIL DATA USER UNTUK CEK ROLE
  db.get("SELECT role FROM users WHERE chat_id = ?", [chatId], (err, user) => {
    const role = user?.role || 'buyer';

    // JIKA BUYER, CEK LIMIT HARIAN
    if (role === 'buyer') {
      checkTrialLimit(chatId, (canTrial) => {
        if (!canTrial) {
          return bot.sendMessage(chatId, '❌ **Jatah Trial Kamu Habis!**\nBuyer hanya boleh trial 1x per hari. Silakan coba lagi besok atau beli saldo untuk jadi Reseller.');
        }
        startProcess(role);
      });
    } else {
      startProcess(role);
    }

    function startProcess(userRole) {
      pendingInputs.add(chatId);
      let username = randomUsername(config.usernamePrefix);
      let password = config.fixedPassword || randomString(6);
      let askId = null;

      const proceedToExec = (min, q, li) => {
        bot.sendMessage(chatId, `⏳ Sedang meracik trial ${config.type.toUpperCase()}...`);
        let args = (config.type === 'ssh') ? [username, password, li, min] :
                   (config.type === 'zivpn') ? [password, min, li] :
                   [username, min, q, li];

        executeScriptRemote(stateData.serverIp, config.scriptName, args, (err, output) => {
          if (err) return finishProcess(bot, chatId, pendingInputs, '❌ Gagal: ' + err.message);
          
          db.run(`INSERT INTO transactions (chat_id, order_id, amount, status, created_at, product_type) 
                  VALUES (?, ?, ?, 'completed', datetime('now', 'localtime'), ?)`, 
                  [chatId, `TRIAL-${Date.now()}`, 0, `TRIAL ${config.type.toUpperCase()}`]);
          
          finishProcess(bot, chatId, pendingInputs, `\`\`\`\n${output}\n\`\`\`\n✅ *Trial ${config.type.toUpperCase()} Berhasil!*`);
        });
      };

      // LOGIKA PEMBATASAN BERDASARKAN ROLE
      if (userRole === 'buyer') {
        // Buyer: Otomatis 30 Menit, 1GB Quota, 1 Limit IP
        proceedToExec(30, 1, 1);
      } else {
        // Reseller: Bebas Input Durasi
        bot.sendMessage(chatId, `⏱ *Masukkan Durasi Trial (Menit):*`, { parse_mode: 'Markdown' })
          .then(m => { askId = m.message_id; });

        bot.once('message', (msg) => {
          if (msg.chat.id !== chatId) return;
          if (!/^\d+$/.test(msg.text)) return finishProcess(bot, chatId, pendingInputs, '⚠️ Harus angka.');
          silentDelete(bot, chatId, askId);
          // Reseller: Quota 100GB (default), Limit IP 2 (default) atau sesuaikan
          proceedToExec(msg.text, 100, 2); 
        });
      }
    }
  });
}

/* ─────────────── EXPORTS ─────────────── */
module.exports = {
  trialSSH: (bot, chatId, userStates, pendingInputs) => {
    runTrial(bot, chatId, userStates, pendingInputs, { type: 'ssh', scriptName: 'triallSSH', usernamePrefix: 'tr_' });
  },
  trialVMess: (bot, chatId, userStates, pendingInputs) => {
    runTrial(bot, chatId, userStates, pendingInputs, { type: 'vmess', scriptName: 'triallVME', usernamePrefix: 't_vme' });
  },
  trialVLess: (bot, chatId, userStates, pendingInputs) => {
    runTrial(bot, chatId, userStates, pendingInputs, { type: 'vless', scriptName: 'triallVLE', usernamePrefix: 't_vle' });
  },
  trialTrojan: (bot, chatId, userStates, pendingInputs) => {
    runTrial(bot, chatId, userStates, pendingInputs, { type: 'trojan', scriptName: 'triallTRO', usernamePrefix: 't_tro' });
  },
  trialZivpn: (bot, chatId, userStates, pendingInputs) => {
    runTrial(bot, chatId, userStates, pendingInputs, { type: 'zivpn', scriptName: 'triallZIV', usernamePrefix: 'ziv', fixedPassword: randomString(8) });
  },
};