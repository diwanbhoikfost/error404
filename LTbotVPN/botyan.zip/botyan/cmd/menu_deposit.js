// cmd/menu_deposit.js
module.exports = async (bot, chatId) => {
  const text = `
┌────────────────────┐
<b>          • TOP UP MANAGERS •</b>
└────────────────────┘
<blockquote>
● Minimal Top Up Rp 5.000
● Saldo Masuk Hitungan detik
● Tidak Ada biaya admin/fee 
</blockquote>
<i>Catatan: Expired Qriss 5 menit</i>
<i>contack: 081312868913</i>
<i>tlegram: @diwanvpn</i>
`;

  const inline_keyboard = [
    [
      { text: 'Rp 5.000', callback_data: 'deposit_5000' },
      { text: 'Rp 10.000', callback_data: 'deposit_10000' },
      { text: 'Rp 15.000', callback_data: 'deposit_15000' }
    ],
    [
      { text: 'Rp 20.000', callback_data: 'deposit_20000' },
      { text: 'Rp 25.000', callback_data: 'deposit_25000' },
      { text: 'Rp 30.000', callback_data: 'deposit_30000' }
    ],
    [
      { text: 'Rp 40.000', callback_data: 'deposit_40000' },
      { text: 'Rp 50.000', callback_data: 'deposit_50000' },
      { text: 'Rp 100.000', callback_data: 'deposit_100000' }
    ],
    [
      { text: 'Nominal Lain (Custom)', callback_data: 'deposit_custom' },
      { text: 'QUIT TO MENU', callback_data: 'menu_back' }
    ]
  ];

  bot.sendMessage(chatId, text, {
    parse_mode: 'HTML',
    reply_markup: { inline_keyboard }
  });
};