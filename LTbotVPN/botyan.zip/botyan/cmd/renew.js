// renew.js
const { Client } = require('ssh2');
const db = require('../data/db');
const prices = require('../data/prices');
const servers = require('../data/server');
const fs = require('fs');
const path = require('path');

/* ─────────────── HELPERS ─────────────── */
function silentDelete(bot, chatId, messageId) {
  if (!messageId) return;
  bot.deleteMessage(chatId, messageId).catch(() => {});
}

function finishProcess(bot, chatId, userStates, text) {
  userStates.delete(chatId);
  bot.sendMessage(chatId, text, { parse_mode: 'Markdown' }).catch(() => {});
}

function checkSaldo(chatId, required, callback) {
  db.get("SELECT saldo FROM users WHERE chat_id = ?", [chatId], (err, row) => {
    if (err || !row) return callback({ success: false, message: '❌ Gagal cek saldo.' });
    if (row.saldo < required) {
      return callback({
        success: false,
        message: `Saldo kurang! Saldo: Rp ${row.saldo.toLocaleString('id-ID')}, Butuh: Rp ${required.toLocaleString('id-ID')}`
      });
    }
    callback({ success: true, saldo: row.saldo });
  });
}

/* ─────────────── REMOTE EXECUTION ENGINE ─────────────── */
function executeScriptRemote(serverIp, scriptFileName, args, callback) {
  const serverConfig = servers.find(s => s.ip === serverIp);
  if (!serverConfig) return callback(new Error('Server tidak terdaftar.'));

  const scriptPath = path.join(__dirname, '..', 'shell_script', scriptFileName);
  if (!fs.existsSync(scriptPath)) return callback(new Error(`File ${scriptFileName} tidak ada di folder shell_script`));
  
  const scriptContent = fs.readFileSync(scriptPath, 'utf8');
  const conn = new Client();

  conn.on('ready', () => {
    const command = `bash -s -- ${args.join(' ')}`;
    conn.exec(command, (err, stream) => {
      if (err) return callback(err);
      let output = '';
      stream.on('data', (data) => { output += data; });
      stream.on('stderr', (data) => { output += data; });
      stream.on('close', () => {
        conn.end();
        callback(null, output.trim());
      });
      stream.end(scriptContent);
    });
  }).on('error', (err) => callback(err))
    .connect({
      host: serverIp,
      port: 22,
      username: 'root',
      password: serverConfig.pass
    });
}

/* ─────────────── 1. RENEW XRAY ─────────────── */
function renewXrayAccount(bot, chatId, userStates, config) {
  const stateData = userStates.get(chatId);
  if (!stateData?.serverIp) return bot.sendMessage(chatId, '❌ Server belum dipilih.');

  let username, days, quota, limitIp;
  bot.sendMessage(chatId, `Input username ${config.type.toUpperCase()} days extension:`).then(() => {
    bot.once('message', (msg) => {
      username = msg.text.trim();
      bot.sendMessage(chatId, 'days extension? ').then(() => {
        bot.once('message', (msg) => {
          days = parseInt(msg.text);
          bot.sendMessage(chatId, 'new limit quota (GB, 0=unlimited):').then(() => {
            bot.once('message', (msg) => {
              quota = msg.text.trim();
              bot.sendMessage(chatId, 'new Limit devic (0=unlimited):').then(() => {
                bot.once('message', (msg) => {
                  limitIp = msg.text.trim();
                  const totalPrice = prices[config.priceKey].perDay * days;

                  checkSaldo(chatId, totalPrice, (res) => {
                    if (!res.success) return finishProcess(bot, chatId, userStates, res.message);
                    bot.sendMessage(chatId, `⏳ renew.....`);
                    
                    executeScriptRemote(stateData.serverIp, `${config.scriptName}`, [username, days, quota, limitIp], (err, output) => {
                      if (err) return finishProcess(bot, chatId, userStates, '❌ Gagal: ' + err.message);

                      // UPDATE SALDO & LOG TRANSAKSI
                      db.run("UPDATE users SET saldo = saldo - ? WHERE chat_id = ?", [totalPrice, chatId]);
                      db.run("INSERT INTO transactions (chat_id, order_id, amount, status, created_at, product_type) VALUES (?, ?, ?, 'completed', datetime('now','localtime'), ?)", 
                        [chatId, `RENEW-${config.type.toUpperCase()}-${Date.now()}`, totalPrice, `RENEW ${config.type.toUpperCase()}`]);

                      finishProcess(bot, chatId, userStates, `\`\`\`\n${output}\n\`\`\`\n✅ Renew ${config.type} Berhasil!`);
                    });
                  });
                });
              });
            });
          });
        });
      });
    });
  });
}

/* ─────────────── 2. RENEW SSH ─────────────── */
function renewSSH(bot, chatId, userStates) {
  const stateData = userStates.get(chatId);
  if (!stateData?.serverIp) return bot.sendMessage(chatId, '❌ Server belum dipilih.');

  let username, days, limitIp;
  bot.sendMessage(chatId, 'input username:').then(() => {
    bot.once('message', (msg) => {
      username = msg.text.trim();
      bot.sendMessage(chatId, 'Days extension:').then(() => {
        bot.once('message', (msg) => {
          days = parseInt(msg.text);
          bot.sendMessage(chatId, 'new Limit ip:').then(() => {
            bot.once('message', (msg) => {
              limitIp = msg.text.trim();
              const totalPrice = prices.ssh.perDay * days;

              checkSaldo(chatId, totalPrice, (res) => {
                if (!res.success) return finishProcess(bot, chatId, userStates, res.message);

                bot.sendMessage(chatId, '⏳ Renew...');
                executeScriptRemote(stateData.serverIp, 'sshRENEW', [username, days, limitIp], (err, output) => {
                  if (err) return finishProcess(bot, chatId, userStates, '❌ Error: ' + err.message);
                  
                  // UPDATE SALDO & LOG TRANSAKSI
                  db.run("UPDATE users SET saldo = saldo - ? WHERE chat_id = ?", [totalPrice, chatId]);
                  db.run("INSERT INTO transactions (chat_id, order_id, amount, status, created_at, product_type) VALUES (?, ?, ?, 'completed', datetime('now','localtime'), 'RENEW SSH')", 
                    [chatId, `RENEW-SSH-${Date.now()}`, totalPrice]);

                  finishProcess(bot, chatId, userStates, `\`\`\`\n${output}\n\`\`\`\n✅ Renew SSH Berhasil!`);
                });
              });
            });
          });
        });
      });
    });
  });
}

/* ─────────────── 3. RENEW ZIVPN ─────────────── */
function renewZivpn(bot, chatId, userStates) {
  const stateData = userStates.get(chatId);
  if (!stateData?.serverIp) return bot.sendMessage(chatId, '❌ Server belum dipilih.');

  let password, days, limitIp;
  bot.sendMessage(chatId, 'input Password:').then(() => {
    bot.once('message', (msg) => {
      password = msg.text.trim();
      bot.sendMessage(chatId, 'Days extension:').then(() => {
        bot.once('message', (msg) => {
          days = parseInt(msg.text);
          bot.sendMessage(chatId, 'new Limit IP:').then(() => {
            bot.once('message', (msg) => {
              limitIp = msg.text.trim();
              const totalPrice = prices.udpzivpn.perDay * days;

              checkSaldo(chatId, totalPrice, (res) => {
                if (!res.success) return finishProcess(bot, chatId, userStates, res.message);

                executeScriptRemote(stateData.serverIp, 'zivRENEW', [password, days, limitIp], (err, output) => {
                  if (err) return finishProcess(bot, chatId, userStates, '❌ Error: ' + err.message);
                  
                  // UPDATE SALDO & LOG TRANSAKSI
                  db.run("UPDATE users SET saldo = saldo - ? WHERE chat_id = ?", [totalPrice, chatId]);
                  db.run("INSERT INTO transactions (chat_id, order_id, amount, status, created_at, product_type) VALUES (?, ?, ?, 'completed', datetime('now','localtime'), 'RENEW ZIVPN')", 
                    [chatId, `RENEW-ZIVPN-${Date.now()}`, totalPrice]);

                  finishProcess(bot, chatId, userStates, `\`\`\`\n${output}\n\`\`\`\n✅ Renew ZIVPN Berhasil!`);
                });
              });
            });
          });
        });
      });
    });
  });
}

module.exports = {
  renewSSH,
  renewVMess: (bot, chatId, userStates) => renewXrayAccount(bot, chatId, userStates, { type: 'vmess', scriptName: 'vmeRENEW', priceKey: 'vmess' }),
  renewVLess: (bot, chatId, userStates) => renewXrayAccount(bot, chatId, userStates, { type: 'vless', scriptName: 'vleRENEW', priceKey: 'vless' }),
  renewTrojan: (bot, chatId, userStates) => renewXrayAccount(bot, chatId, userStates, { type: 'trojan', scriptName: 'troRENEW', priceKey: 'trojan' }),
  renewZivpn
};