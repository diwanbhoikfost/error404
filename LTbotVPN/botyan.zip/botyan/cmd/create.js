// create.js - UPDATED WITH ROLE LIMITS
const { Client } = require('ssh2');
const db = require('../data/db');
const prices = require('../data/prices');
const servers = require('../data/server');
const fs = require('fs');
const path = require('path');

/* ─────────────── HELPERS ─────────────── */
function silentDelete(bot, chatId, messageId) {
  if (!messageId) return;
  bot.deleteMessage(chatId, messageId).catch(() => {});
}

function finishProcess(bot, chatId, userStates, text) {
  userStates.delete(chatId);
  bot.sendMessage(chatId, text, { parse_mode: 'Markdown' }).catch(() => {});
}

function getUserData(chatId, callback) {
  db.get("SELECT saldo, role FROM users WHERE chat_id = ?", [chatId], (err, row) => {
    if (err || !row) return callback({ success: false, message: '❌ User tidak ditemukan.' });
    callback({ success: true, saldo: row.saldo, role: row.role || 'buyer' });
  });
}

function executeScriptRemote(serverIp, scriptFileName, args, callback) {
  const serverConfig = servers.find(s => s.ip === serverIp);
  if (!serverConfig) return callback(new Error('Server tidak terdaftar'));

  const scriptPath = path.join(__dirname, '..', 'shell_script', scriptFileName);
  if (!fs.existsSync(scriptPath)) return callback(new Error(`File ${scriptFileName} tidak ada`));
  
  const scriptContent = fs.readFileSync(scriptPath, 'utf8');
  const conn = new Client();

  conn.on('ready', () => {
    const command = `bash -s -- ${args.join(' ')}`;
    conn.exec(command, (err, stream) => {
      if (err) return callback(err);
      let output = '';
      stream.on('data', (data) => { output += data; });
      stream.on('stderr', (data) => { output += data; });
      stream.on('close', () => {
        conn.end();
        callback(null, output.trim());
      });
      stream.end(scriptContent);
    });
  }).on('error', (err) => callback(err)).connect({
    host: serverIp, port: 22, username: 'root', password: serverConfig.pass
  });
}

/* ─────────────── 1. CREATE SSH ─────────────── */
function createSSH(bot, chatId, userStates) {
  const stateData = userStates.get(chatId);
  if (!stateData?.serverIp) return bot.sendMessage(chatId, '❌ Server belum dipilih.');

  getUserData(chatId, (user) => {
    if (!user.success) return bot.sendMessage(chatId, user.message);

    let username, password, limitIp, days;
    const askIds = [];
    const cleanup = () => askIds.forEach(id => silentDelete(bot, chatId, id));

    bot.sendMessage(chatId, '🆔 SSH username:').then(m => askIds.push(m.message_id));
    bot.once('message', (msg) => {
      username = msg.text.trim();
      bot.sendMessage(chatId, '🔑 SSH password:').then(m => askIds.push(m.message_id));
      bot.once('message', (msg) => {
        password = msg.text.trim();
        
        const askDuration = () => {
          bot.sendMessage(chatId, '📅 Active period (days):').then(m => askIds.push(m.message_id));
          bot.once('message', (msg) => {
            days = parseInt(msg.text);
            const totalHarga = prices.ssh.perDay * days;

            if (user.saldo < totalHarga) return finishProcess(bot, chatId, userStates, `⚠️ Saldo tidak cukup. Harga: Rp ${totalHarga}`);

            cleanup();
            bot.sendMessage(chatId, `⏳ Creating SSH...`);
            executeScriptRemote(stateData.serverIp, 'buatSSH', [username, password, limitIp, days], (err, output) => {
              if (err) return finishProcess(bot, chatId, userStates, '❌ Gagal: ' + err.message);
              db.run("UPDATE users SET saldo = saldo - ? WHERE chat_id = ?", [totalHarga, chatId]);
              db.run("INSERT INTO transactions (chat_id, order_id, amount, status, created_at, product_type) VALUES (?, ?, ?, 'completed', datetime('now','localtime'), 'SSH')", [chatId, `SSH-${Date.now()}`, totalHarga]);
              finishProcess(bot, chatId, userStates, `\`\`\`\n${output}\n\`\`\`\n✅ Akun SSH Berhasil!`);
            });
          });
        };

        if (user.role === 'buyer') {
          limitIp = 2; // Paksa limit 2 untuk buyer
          askDuration();
        } else {
          bot.sendMessage(chatId, '🔢 Limit Ip:').then(m => askIds.push(m.message_id));
          bot.once('message', (msg) => {
            limitIp = msg.text.trim();
            askDuration();
          });
        }
      });
    });
  });
}

/* ─────────────── 2. CREATE XRAY (VMESS/VLESS/TROJAN) ─────────────── */
function createStandardType(bot, chatId, userStates, config) {
  const stateData = userStates.get(chatId);
  getUserData(chatId, (user) => {
    if (!user.success) return bot.sendMessage(chatId, user.message);

    bot.sendMessage(chatId, config.usernamePrompt).then(() => {
      bot.once('message', (msg) => {
        let username = msg.text.trim();
        bot.sendMessage(chatId, '📅 Active Period (days):').then(() => {
          bot.once('message', (msg) => {
            let days = parseInt(msg.text);
            
            const execXray = (q, li) => {
              const totalHarga = prices[config.priceKey].perDay * days;
              if (user.saldo < totalHarga) return finishProcess(bot, chatId, userStates, `⚠️ Saldo tidak cukup.`);
              
              bot.sendMessage(chatId, `⏳ Creating ${config.type.toUpperCase()}...`);
              executeScriptRemote(stateData.serverIp, config.scriptName, [username, days, q, li], (err, output) => {
                if (err) return finishProcess(bot, chatId, userStates, '❌ Gagal: ' + err.message);
                db.run("UPDATE users SET saldo = saldo - ? WHERE chat_id = ?", [totalHarga, chatId]);
                db.run("INSERT INTO transactions (chat_id, order_id, amount, status, created_at, product_type) VALUES (?, ?, ?, 'completed', datetime('now','localtime'), ?)", [chatId, `${config.type.toUpperCase()}-${Date.now()}`, totalHarga, config.type.toUpperCase()]);
                finishProcess(bot, chatId, userStates, `\`\`\`\n${output}\n\`\`\`\n✅ Akun ${config.type} Berhasil!`);
              });
            };

            if (user.role === 'buyer') {
              execXray(300, 2); // Buyer: Quota 300GB, Limit 2
            } else {
              bot.sendMessage(chatId, '💾 Quota Limit (GB):').then(() => {
                bot.once('message', (msg) => {
                  let quota = msg.text.trim();
                  bot.sendMessage(chatId, '🔢 Limit IP:').then(() => {
                    bot.once('message', (msg) => {
                      execXray(quota, msg.text.trim());
                    });
                  });
                });
              });
            }
          });
        });
      });
    });
  });
}

/* ─────────────── 3. CREATE ZIVPN ─────────────── */
function createZivpn(bot, chatId, userStates) {
  const stateData = userStates.get(chatId);
  getUserData(chatId, (user) => {
    bot.sendMessage(chatId, '🔑 ZIVPN Password:').then(() => {
      bot.once('message', (msg) => {
        let password = msg.text.trim();
        bot.sendMessage(chatId, '📅 Active Period (days):').then(() => {
          bot.once('message', (msg) => {
            let days = msg.text.trim();
            
            const execZiv = (li) => {
              const totalHarga = prices.udpzivpn.perDay * parseInt(days);
              if (user.saldo < totalHarga) return finishProcess(bot, chatId, userStates, `⚠️ Saldo tidak cukup.`);
              executeScriptRemote(stateData.serverIp, 'buatZIVPN', [password, days, li], (err, output) => {
                if (err) return finishProcess(bot, chatId, userStates, '❌ Error: ' + err.message);
                db.run("UPDATE users SET saldo = saldo - ? WHERE chat_id = ?", [totalHarga, chatId]);
                db.run("INSERT INTO transactions (chat_id, order_id, amount, status, created_at, product_type) VALUES (?, ?, ?, 'completed', datetime('now','localtime'), 'ZIVPN')", [chatId, `ZIVPN-${Date.now()}`, totalHarga]);
                finishProcess(bot, chatId, userStates, `\`\`\`\n${output}\n\`\`\`\n✅ Akun ZIVPN Berhasil!`);
              });
            };

            if (user.role === 'buyer') {
              execZiv(2); // Buyer: Limit 2
            } else {
              bot.sendMessage(chatId, '🔢 Limit IP:').then(() => {
                bot.once('message', (msg) => {
                  execZiv(msg.text.trim());
                });
              });
            }
          });
        });
      });
    });
  });
}

module.exports = {
  createSSH,
  createVMess: (bot, chatId, userStates) => createStandardType(bot, chatId, userStates, {
    type: 'vmess', scriptName: 'buatVME', priceKey: 'vmess', usernamePrompt: '🆔 VMESS username:'
  }),
  createVLess: (bot, chatId, userStates) => createStandardType(bot, chatId, userStates, {
    type: 'vless', scriptName: 'buatVLE', priceKey: 'vless', usernamePrompt: '🆔 VLESS username:'
  }),
  createTrojan: (bot, chatId, userStates) => createStandardType(bot, chatId, userStates, {
    type: 'trojan', scriptName: 'buatTRO', priceKey: 'trojan', usernamePrompt: '🆔 TROJAN username:'
  }),
  createZivpn
};