// data/prices.js
module.exports = {
  ssh:     { perDay: 400 },
  vmess:   { perDay: 400 },
  vless:   { perDay: 400 },
  trojan:  { perDay: 400 },
  udpzivpn: { perDay: 250 }
};