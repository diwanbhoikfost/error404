const servers = [
  {
    id: 1,
    name: "Sg NEWMEDIA",
    ip: "103.14.79.231",
    pass: "TWNAY5Tz",
    domain: "c2opi.execshell.cloud",
    provider: "Newmedia Express Pte LTD"
  }
];

module.exports = servers;