#!/usr/bin/env bash
clear

DATA_DIR="/usr/bin/botyan/data"
FILE="$DATA_DIR/server.js"

mkdir -p $DATA_DIR

# Ambil info VPS
CITY=$(curl -s ipinfo.io/city)
ISP=$(curl -s ipinfo.io/org | cut -d " " -f 2-)

# Input user
read -p "Masukan IP VPS       : " ipvps
read -p "Masukan Password VPS : " pw
read -p "Masukan Domain       : " host
read -p "nama server contoh : Indo dewaweb / sgdo : " host

# Jika file belum ada, buat template awal
if [ ! -f "$FILE" ]; then
cat > $FILE <<'EOF'
const servers = [
];

module.exports = servers;
EOF
fi

# Ambil ID terakhir
LAST_ID=$(grep "id:" $FILE | tail -n1 | grep -oE '[0-9]+' || echo 0)
NEW_ID=$((LAST_ID + 1))

# Buat object server baru
NEW_SERVER=$(cat <<EOF
  {
    id: $NEW_ID,
    name: "🌏 $CITY-$NEW_ID",
    ip: "$ipvps",
    pass: "$pw",
    domain: "$host",
    provider: "$ISP"
  }
EOF
)

# Sisipkan sebelum penutup array ];
sed -i "/^];/i $NEW_SERVER," $FILE

echo ""
echo "✅ Server berhasil ditambahkan!"
echo "📍 City     : $CITY"
echo "🏢 Provider : $ISP"
echo "🆔 ID       : $NEW_ID"