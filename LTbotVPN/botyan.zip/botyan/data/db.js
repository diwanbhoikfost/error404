// data/db.js
const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const dbPath = path.join(__dirname, 'yanbot.db');

const db = new sqlite3.Database(dbPath, sqlite3.OPEN_READWRITE | sqlite3.OPEN_CREATE, (err) => {
  if (err) {
    console.error('Gagal buka database:', err.message);
  } else {
    console.log('Database berhasil dibuka di:', dbPath);
  }
});

db.serialize(() => {
  // Update tabel users (Ganti 'user' jadi 'buyer' agar serasi dengan create.js)
  db.run(`CREATE TABLE IF NOT EXISTS users (
    chat_id INTEGER PRIMARY KEY,
    saldo INTEGER DEFAULT 0,
    role TEXT DEFAULT 'buyer', 
    created_at TEXT
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS transactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    chat_id INTEGER,
    order_id TEXT,
    amount INTEGER,
    status TEXT DEFAULT 'pending',
    created_at TEXT,
    product_type TEXT DEFAULT ''
  )`);
});

module.exports = db;